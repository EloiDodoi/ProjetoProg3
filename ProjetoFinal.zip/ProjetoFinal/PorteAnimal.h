#ifndef PORTEANIMAL_H
#define PORTEANIMAL_H

#include <iostream>
#include <string>

using namespace std;

class PorteAnimal{

    private:
        int IdPorte;
        string Tipo;
    
    public:
        PorteAnimal();
        ~PorteAnimal();
        
        int getId(){
            return IdPorte;
        }
        void setId(int id){
            IdPorte = id;
        }

        string getTipo(){
            return Tipo;
        }
        void setTipo(string tipo){
            Tipo = tipo;
        }
};

#endif